/*----------------------------------------------------------------*/
/* Author: 		Noemi Johnson
/* Class:  		CSCE 3193 
/* Title: 		Assignment 4
/* Date:        3/3/2018
/* Synopsis: 	BBQGoomba.java is part of the Game program
/*---------------------------------------------------------------*/
import java.util.*;
import java.util.ArrayList;
import java.lang.StringBuilder;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.File;
import javax.imageio.ImageIO;



public class BBQGoomba extends Sprite   
{
	boolean movingRight; //increment or decrement the position. He can slide it. 
	  
	static BufferedImage bbq_goomba;
	
	ArrayList<Sprite> sprites;
	boolean kill_sprite = false; 
	boolean roastingGoomba = false;
	 
	Model model;
	int prev_x;
	int prev_y;
	int frameCount;
	
	 BBQGoomba(Model m)
	 {
		model = m;
		x = model.goomba.x;
		y = model.goomba.y;
		 w = 99;
		 h = 118;
		
		sprites = new ArrayList<Sprite>();		
		 //Trying to lazy-load a tube image:
		if (bbq_goomba == null)
		{
			bbq_goomba = loadImage("goomba_fire.png");
		}
		 
	 }
	 
	  //This will help the sprite class tell if it is a tube or not.
	 boolean isTube()
	{
		return false;
	}
	
	//This will help the sprite class tell if it is a Mario or not.
	boolean isMario()
	{
		return false;
	}
	
	//This will help the sprite class tell if it is a Goomba or not.
	boolean isGoomba()
	{
		return false;
	}
	
	boolean isFireball()
	{
		return false;
	}
	
	boolean isBBQGoomba()
	{
		return true;
	}
	
	//BBQ has collided. And Vice-Versa
	boolean isCollidable()
	{
		return false; 
	}
	
	boolean firedShot()
	 {
		return false; 
	 }
	
	 void update()
	 {
		if(movingRight)
			
			x +=5;
			
			else
			
			x -= 5;

		  //testing for collisions:
			for (int i = 0; i < model.sprites.size();i++)
			{
					 Sprite s = model.sprites.get(i);
					    
						if(s.isCollidable() && Sprite.doesItCollide(this, s))
						{	
								this.disappear();	
						}
			}	
		
	 }
	 
	void disappear()
    {	 
	     
			x =- 2000;
			y =- 2000;
		    kill_sprite = true;
    }	
	
	
		void draw(Graphics g) 
		{
			g.drawImage(BBQGoomba.bbq_goomba, x - model.cameraPos(), y, null);
			
		}
		
	

	     //this method will keep track of Goomba's last position:
		public void rememberState() 
		{
		    prev_x = x;
			prev_y = y;
		
		} 
	  
	static BufferedImage loadImage(String filename)
	{
		BufferedImage bbq_goomba = null;
		
		try
		{
			//You need to use this to tell the compiler which tube object to use.
			bbq_goomba = ImageIO.read(new File(filename));	
		} 
		catch(Exception e) 
		{
			e.printStackTrace(System.err);
			System.exit(1);
		}
		return bbq_goomba;
	}
}