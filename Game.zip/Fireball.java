/*----------------------------------------------------------------*/
/* Author: 		Noemi Johnson
/* Class:  		CSCE 3193 
/* Title: 		Assignment 4
/* Date:       
/* Synopsis: 	Fireball.java is part of the Game program
/*---------------------------------------------------------------*/
import java.util.ArrayList;
import java.lang.StringBuilder;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.File;
import javax.imageio.ImageIO;
import java.awt.Color;


public class Fireball extends Sprite  
{
	static BufferedImage fireball;
	 
	 ArrayList<Sprite> sprites;
	 
    boolean roastingGoomba = false;
	  
	  
	  //Boolean to determing to kill sprite:
	 boolean kill_sprite = false; 
	 
	 boolean shotFireball;
	
	 int fireballCount;
	  
	 int offGroundFrameCount;
	 
	 double fireBall_vert_velocity;
	 
	 int prev_x;
	 int prev_y;
	   
	
	
    Model model;
	
	 Fireball(Model m)
	 {
		model = m;
		x = model.mario.x;
		y = model.mario.y;
		 w = 5;
		 h = 5;
		
		fireBall_vert_velocity = -12.0;
		
		 sprites = new ArrayList<Sprite>();
		 
		 //if the fireball is null on the list and mario did shoot a fire ball (true), this should load the image
		 if (fireball == null)
		 {
			fireball = loadImage("fireball.png");
		 }
			 
	  }
	 
	
			
	  //This will help the sprite class tell if it is a tube or not.
	boolean isTube()
	{
		return false;
	}
	
	//This will help the sprite class tell if it is a Mario or not.
	boolean isMario()
	{
		return false;
	}
	
	boolean isGoomba()
	{
		return false;
	}
	
	boolean isFireball()
	{
		return true;
	}
	
    boolean isBBQGoomba()
	{
		return false;
	}
	
	//A sprite should not collide with itself
	boolean isCollidable()
	{
		return false; 
	}
	
	
	void shoot()
	{
		x =+5;
			
	}
		
		
	 	void fireBalljump()
		{
			
			fireBall_vert_velocity -= 20.0;
		}
		
	void fireball_collide(Sprite s)
    {
	//	System.out.println("Inside the fireball collide function");
		
			if(this.x + this.w >= s.x && prev_x + this.w < s.x)
			{
				this.x = s.x - this.w - 1;
			
			    kill_sprite = true;
			}
			else if(this.x <= s.x + s.w && prev_x > s.x + s.w)
			{
				this.x = s.x + s.w + 1;
				
				kill_sprite = true;
			}
			else if(this.y + this.h >= s.y && prev_y + this.h < s.y)
			{
				this.y = s.y - this.h - 1;
				offGroundFrameCount = 0; //Sprite is on the ground.
				 
				kill_sprite = true;
			}
			else if(this.y <= s.y + s.h && prev_y > s.y + s.h)
			{
				this.y = s.y + s.h + 1;
			//    fireBall_vert_velocity += 20; 
				kill_sprite = true;
			}
			else
				System.out.println("How did I get in here?");
	
	}
	
	public void update()
	{
					 
		x += 5;
		y -= 5;
			fireBall_vert_velocity += 6.9;
			y += fireBall_vert_velocity;

			if(y > 400  )
			{
				fireBall_vert_velocity = 0.0;
				y = 400; // snap back to the ground
			
				offGroundFrameCount = 0;
			}
		
			offGroundFrameCount++;
			//testing for collisions:
			for (int i = 0; i < model.sprites.size();i++)
			{
					Sprite s = model.sprites.get(i);
					
					if(s.isCollidable())
					{	
				      
						if(s.isGoomba())
						{
							model.bbqgoomba.update();
							 Goomba g = (Goomba)s;
							 
							if (Sprite.doesItCollide(this, g))
							 { 
						        roastingGoomba = true;
								fireball_collide(g);
								model.bbqgoomba.update();
								
								kill_sprite = true;
								
							 }
						}
					}
				     if (s.isCollidable())
					{
					   
						if (s.isTube())
						{ 	
							Tube t = (Tube)s;
							
							if (Sprite.doesItCollide(this, t))
							{
								    fireball_collide(t);
									fireBalljump();
									
									kill_sprite = true;
							}
						}
					}
					else
						
					  kill_sprite = true;
			}
		   
	}
	 
		
		void draw(Graphics g) 
		{
			g.drawImage(Fireball.fireball, x - model.cameraPos(), y, null);
			
		}

	     //this method will keep track of Fireball's last position:
		public void rememberState() 
		{
		    prev_x = x;
			prev_y = y;
		
		} 
	  
	static BufferedImage loadImage(String filename)
	{
		BufferedImage fireball = null;
		
		//This code was added to the View constructor to load this image from disk: 
		try
		{
			//You need to use this to tell the compiler which tube object to use.
			fireball = ImageIO.read(new File(filename));	
		} 
		catch(Exception e) 
		{
			e.printStackTrace(System.err);
			System.exit(1);
		}
		return fireball;
	}
	
      
	
 
}