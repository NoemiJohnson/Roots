/*---------------------------------------------------------------*/
/* Author: 		Noemi Johnson
/* Class:  		CSCE 3193 
/* Title: 		Assignment 4
/* Date:        
/* Synopsis: 	View.java is part of the Game program
/*--------------------------------------------------------------*/

import java.awt.Color;
import javax.swing.JPanel; 
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.io.File;
import java.awt.event.ActionListener;


//JPanel is a class provided by Java. JPanel makes the java window. 
class View extends JPanel 
{
	Model model;
	int scrollPos;

	
	/* View constructor has the Controller parameter passed to it when a
	  new View() is instantiated. This constructor also takes the Model m variable */
	View(Controller c, Model m) 
	{
		//stores m in the model variable:
		this.model = m;
		c.setView(this);	
	}
	
	 //This method will draw the image of the tube, set the cyan color background and fills the rectangle: 
	 public void paintComponent(Graphics g)
	{
		g.setColor(new Color(128, 255, 255));
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		//draws the ground underneath Mario:
		g.setColor(Color.gray);
		g.drawLine(0, 495, 1000, 495);
		
		
	
		//System.out.println(model.sprites.size());
		for(int i = 0; i < model.sprites.size(); i++)
		{
			Sprite s = model.sprites.get(i);
			
			s.draw(g); 
			
		}
	}	
}
