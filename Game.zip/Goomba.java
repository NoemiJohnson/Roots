/*----------------------------------------------------------------*/
/* Author: 		Noemi Johnson
/* Class:  		CSCE 3193 
/* Title: 		Assignment 4
/* Date:        3/3/2018
/* Synopsis: 	Goomba.java is part of the Game program
/*---------------------------------------------------------------*/
import java.util.*;
import java.util.ArrayList;
import java.lang.StringBuilder;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.File;
import javax.imageio.ImageIO;



public class Goomba extends Sprite   
{
	//Boolean to determing Goomba sliding left to right:
	boolean movingRight;  
	
	//Boolean to determing to kill sprite:
	boolean kill_sprite = false;  
	
	// determines if a Goomba is hit by a fireball
	boolean roastingGoomba = false; 
	

	static BufferedImage goomba;

	
	ArrayList<Sprite> sprites;
	
	 //keeping track of the cooking time:
	int cooking_time; 
	
	//Goomba's previous x positon:
	int prev_x;
	
	//Goomba's previous y positon:
	int prev_y;
	
	//Frame count:
	int frameCount;
	
	//Goomba is well-done so it must dissapear
	final int well_done = 5; 
	
	Model model;
	
	
	 Goomba(Model m)
	 {
		 model = m;
		 x = 450;
		 y = 495 - 118;
		 w = 99;
		 h = 118;
		
		sprites = new ArrayList<Sprite>();	
		
		if (goomba == null)
		{
			goomba = loadImage("goomba.png");
		}	
        
	 }
	 
	  //This will help the sprite class tell if it is a tube or not.
	 boolean isTube()
	{
		return false;
	}
	
	//This will help the sprite class tell if it is a Mario or not.
	boolean isMario()
	{
		return false;
	}
	
	//This will help the sprite class tell if it is a Goomba or not.
	boolean isGoomba()
	{
		return true;
	}
	
	//This will help the sprite class tell if it is a Fireball or not.
	boolean isFireball()
	{
		return false;
	}
	
	//Goomba can collide with a tube. And Vice-Versa
	boolean isCollidable()
	{
		return false; 
	}
	
	//This will help the sprite class tell if it is a Fireball or not.
   boolean isBBQGoomba()
	{
		return false;
	}
  
	
	
	void update()
	{
			if(movingRight)
			
				x +=5;
			
			else
			
				x -= 5;
		
			
			 
			  //testing for collisions:
				for (int i = 0; i < model.sprites.size();i++)
				{
					  Sprite s = model.sprites.get(i);
					
						if(s.isCollidable() )
						{
						    if (s.isTube())
							{
							   Tube t = (Tube)s;
							   
							    if (Sprite.doesItCollide(this, t))
								{
									
									movingRight = !movingRight;
									
									stop();
										
								}
								
							}
					    }
						else if (s.isCollidable() && Sprite.doesItCollide(this, s))
						{
							if (s.isFireball())
							{
								this.stop();
								sprites.remove(this);
								
								setOnFire((Fireball)s);
										
								
							}
						}
				}	
				
		
	}
	
	void stop()
	{
		 if(!movingRight)
		 {
			
			x -=2000;
			y -=2000;
			
		 }
	}		
	

	 void setOnFire(Sprite s)
    {
			if(this.x + this.w >= s.x && prev_x + this.w < s.x)
			{
				this.x = 0;
			     sprites.remove(this);
				model.bbqgoomba.update();
			   
				
			
			}
			else if(this.x <= s.x + s.w && prev_x > s.x + s.w)
			{
				this.x = 0;
				sprites.remove(this);
				
				model.bbqgoomba.update();
				
				
	
			}
			else if(this.y + this.h >= s.y && prev_y + this.h < s.y)
			{
				this.y = 0;
				sprites.remove(this);
				
				model.bbqgoomba.update();
				
			}
			else if(this.y <= s.y + s.h && prev_y > s.y + s.h)
			{
				this.y = 0;
				sprites.remove(this);
				model.bbqgoomba.update();
				
				
			}
			else
				System.out.println("Goomba is not cooked yet!");
	}  
		void draw(Graphics g) 
		{
			
				g.drawImage(Goomba.goomba, x - model.cameraPos(), y, null);
			
		}		
 		
		
	     //this method will keep track of Goomba's last position:
		public void rememberState() 
		{
		    prev_x = x;
			prev_y = y;
		
		} 
	  
	static BufferedImage loadImage(String filename)
	{
		BufferedImage goomba = null;
		
		try
		{
			//You need to use this to tell the compiler which object to use.
			goomba = ImageIO.read(new File(filename));
						
		} 
		catch(Exception e) 
		{
			e.printStackTrace(System.err);
			System.exit(1);
		}
		return goomba;
	}
    
	
	
 
}