/*----------------------------------------------------------------*/
/* Author: 		Noemi Johnson
/* Class:  		CSCE 3193 
/* Title: 		Assignment 4
/* Date:        2/23/18
/* Synopsis: 	Sprite.java is part of the Game program
/*---------------------------------------------------------------*/
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.Iterator;

abstract public class Sprite
{
	
	int x; //Both Tube, Goomba and Mario have this. 
	int y; //Both Tube, Goomba and Mario have this. 
	int w; //Both Tube, Goomba and Mario have this. 
	int h; //Both Tube, Goomba and Mario have this.
	
	abstract void draw(Graphics g);

	abstract boolean isTube();
	abstract boolean isGoomba();
	abstract boolean isMario();
	abstract boolean isFireball();
	abstract boolean isCollidable(); 
    boolean roastingGoomba;
	abstract boolean isBBQGoomba(); 
  
	abstract void update();
    boolean kill_sprite; 
	
	abstract void rememberState();

	//collision detection between 2 sprites:
	static boolean doesItCollide(Sprite a, Sprite b)
	{
		if (a.x + a.w < b.x) return false;
		if (a.x > b.x + b.w) return false;
		if (a.y + a.h < b.y) return false;
		if (a.y > b.y + b.h) return false;
		return true;		
	} 
	
}



   	
	
	


