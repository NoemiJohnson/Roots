/*----------------------------------------------------------------*/
/* Author: 		Noemi Johnson
/* Class:  		CSCE 3193 
/* Title: 		Assignment 4
/* Date:        3/3/2018
/* Synopsis: 	Mario.java is part of the side scroller map editor
/*---------------------------------------------------------------*/

import java.util.ArrayList;
import java.util.Iterator;
import java.lang.StringBuilder;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.File;
import javax.imageio.ImageIO;


//Mario class:
 public class Mario extends Sprite 
{
	// this will be used for lazy-loading the image:
	 static BufferedImage[] marios;
	
	boolean roastingGoomba = false;
	
	//Boolean to determing to kill sprite:
	 boolean kill_sprite = false; 
	 
	 Fireball fireball;
	 Model model;
	 int prev_x;
	 int prev_y;
	 double vert_velocity;
	 int offGroundFrameCount; 
     int dist_from_left = 200;
	
	Mario(Model m)
	 {
		model = m;
		
		//Mario's starting positions:
		 x = 200; 
		 y = 400;
		 w = 60;
		 h = 95;
		 vert_velocity = -12.0;
		
	    marios = new BufferedImage[5];
		marios[0] = loadImage("mario0.png");
		marios[1] = loadImage("mario1.png");		
		marios[2] = loadImage("mario2.png");
		marios[3] = loadImage("mario3.png");
		marios[4] = loadImage("mario4.png");
		 	
	 }
	 
	 //This will help the sprite class tell if it is a tube or not.
	boolean isTube()
	{
		return false;
	}
	
	//This will help the sprite class tell if it is a Mario or not.
	boolean isMario()
	{
		return true;
	}
	
	//This will help the sprite class tell if it is a Goomba or not.
	boolean isGoomba()
	{
		return false;
	}
	 
	//Mario can collide with a tube. And Vice-Versa
	boolean isCollidable()
	{
		return false; 
	}
	
	//This will help the sprite class tell if it is a Fireball or not.
	 boolean isFireball()
	{
		return false;
	}
	
	boolean isBBQGoomba()
	{
		return false;
	}
	
	//When Mario shoots a fireball, it will call the fireball.update() method.
	void shotFireBall()
	{
		fireball.update();	
	}
	
	//Loading an image:
	static BufferedImage loadImage(String filename)
	{
		BufferedImage man = null;
		try
		{
			
			man = ImageIO.read(new File(filename));	
		} 
		catch(Exception e) 
		{
			e.printStackTrace(System.err);
			System.exit(1);
		}
		return man;
	} 
	
	// method for Mario to draw itself using the sprite class through polymorphism
	public void draw(Graphics g)
	 { 
	
		//this will load Mario images based on the frame. If Mario is standing still, the first image of the ArrayList of sprites should be Mario[0]
		int frame = Math.abs((x / 20) % 5);
		
		g.drawImage(marios[frame], x - model.cameraPos(), y, null);
	
	
	 }
	

	//This method has to be modified for sprite collision detection from the upper corner of both Mario
	// and the tube's upper corners.
	void getOutOfTheTube(Sprite s)
    {
			if(this.x + this.w >= s.x && prev_x + this.w < s.x)
			{
				this.x = s.x - this.w - 1;
			
			}
			else if(this.x <= s.x + s.w && prev_x > s.x + s.w)
			{
				this.x = s.x + s.w + 1;
	
			}
			else if(this.y + this.h >= s.y && prev_y + this.h < s.y)
			{
				this.y = s.y - this.h - 1;
				offGroundFrameCount = 0; //Sprite is on the ground.
				vert_velocity = 0; //stops the fall by the tube. 
			}
			else if(this.y <= s.y + s.h && prev_y > s.y + s.h)
			{
				this.y = s.y + s.h + 1;
				
			}
			else
				System.out.println("How did I get in here?");
	}
	
	//Mario's jumping velocity:	 
   	void jump()
	{
		vert_velocity -= 28.0;
	}
 
    //this method will keep track of Mario's last position:
	public void rememberState()
	{
		prev_x = x;
	    prev_y = y;
	}
	  

	public void update()
	{
			
			vert_velocity += 6.9;
			y += vert_velocity;

			if(y > 400 )
			{
				vert_velocity = 0.0;
				y = 400; // snap back to the ground
				offGroundFrameCount = 0;
			}
		
			offGroundFrameCount++;
	
			for (int i =0; i < model.sprites.size();i++)
			{
				Sprite s = model.sprites.get(i);
			
				if(s.isCollidable() && Sprite.doesItCollide(this, s))
				{
					//if this is a tube, it should collide with either Mario
					if(s.isTube()) 
					{	
						getOutOfTheTube((Tube)s);
					}
				
					else
					{
						throw new RuntimeException("Mario collided with something I don't know how to handle");
					}
				}
			}
		
		
	}
}

