/*---------------------------------------------------------------*/
/* Author: 		Noemi Johnson
/*
/* Class:  		CSCE 3193 
/* Title: 		Assignment 4
/* Date:        3/3/2018
/* Synopsis: 	Model.java is part of the Game program
/*---------------------------------------------------------------*/
import java.util.*; //To use the ArrayList
import java.lang.StringBuilder;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.lang.Boolean;

//Model class:
class Model 
{
	//Mario class that has a reference variable used as a redundant pointer;
	Mario mario;
	Goomba goomba;
	Fireball fireball;
    Tube tube;
	BBQGoomba bbqgoomba;
	
	//This is a vector of tube type called Sprite using polymorphism - using the same method to do their own way according to the object's settings. 
	ArrayList<Sprite> sprites;
	
    int dest_x;
    int dest_y;
   	
	//Model constructor:
 	Model()
	{
		
 	    sprites = new ArrayList<Sprite>();
		mario = new Mario(this);
 		sprites.add(mario);
		
		sprites.add(new Tube(330, 400, this));
		sprites.add(new Tube(630, 400, this));
		
		goomba = new Goomba(this);
		sprites.add(goomba);
		
		addAnother();	
	    removeIt();
		
		
	} 
	
	void removeGoomba()
	{
		goomba = new Goomba (this);
		sprites.remove(goomba);
		addBBQGoomba();
		
	}
	void addAnother()
	{
		
		fireball = new Fireball(this);
		sprites.add(fireball);	
			
	}
	
	void addBBQGoomba()
	{
		
		bbqgoomba = new BBQGoomba(this);
		sprites.add(bbqgoomba);	
	}
	void removeIt()
	{
		
		fireball = new Fireball(this);
		sprites.remove(fireball);

	}
	int cameraPos()
	{
		return mario.x - mario.dist_from_left;
	}
	
	//makes the game remember the before and after the state.
	 //Dr. Gashler added this method on 2/20/18:
	void rememberState()
	{
		//This method will make the rest of the rememberState methods in other classes update as sprites:
		for(int i = 0; i < sprites.size(); i++)
		{
			sprites.get(i).rememberState();
		}
	}
	
	void update()
	{	
		for (Iterator<Sprite> it = sprites.iterator(); it.hasNext(); )
		{
			Sprite s = it.next(); 
			
			s.update(); 
			
			 if(s.kill_sprite)
			{
			
				sprites.remove(s);
			} 
		}
		
	}
	
	public void setDestination(int x, int y)
	{
		this.dest_x = x;
		this.dest_y = y;
	}
	
	

}	
  
  
