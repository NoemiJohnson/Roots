/*---------------------------------------------------------------*/
/* Author: 		Noemi Johnson
/* Class:  		CSCE 3193 
/* Title: 		Assignment 4
/* Date:        2/23/18
/* Synopsis: 	Game.java is part of the side scroller map editor
/*--------------------------------------------------------------*/


import javax.swing.JFrame;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class Game extends JFrame 
{
	//Member variables:
	View view; 
	Controller controller; 
	Model model; 
	Tube tube;
	Sprite sprite;
	Goomba goomba;
	Fireball fireball;
	BBQGoomba bbqgoomba;
	
	static int state;
    
	//Game constructor:
	public Game() 
	{
		//Initializing the member variables:
		model = new Model();
		controller = new Controller(model);
		view = new View(controller, model); 
	  
	    /* Configuring the window's settings:
		   This tells the program to also use the KeyListener for input! 
		   This is necessary for Windows, not Linux.
		*/
		this.setFocusable(true);	
		this.setTitle("Game");
		this.setSize(1000, 700);
		this.getContentPane().add(view);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		
		//Setting up the input devices:
		this.addKeyListener(controller);
		view.addMouseListener(controller); //should fix the scrolling problem	
		
	}
		
	//This runs the update methods for each class using a while loop:
	public void run()
	{
		while(true)
		{
			//uses the controller object using the update method:
			controller.update(); 
			
			 // uses the model object using the update method
		    model.update(); 
			
			// Indirectly calls View.paintComponent
			view.repaint(); 	
			
			// Updates the screen:
			Toolkit.getDefaultToolkit().sync();
			
			// Go to sleep for 25 milliseconds. After that it will resume for frame intervals once every 40 miliseconds
			try
			{
				//Uses the thread class to call the sleep method
				Thread.sleep(25); 
			} 
			
			catch(Exception e) 
			{
				e.printStackTrace();
				System.exit(1);					
			}		
		}
	}
	
	//main program method. Game g is an object. 
	public static void main(String[] args) 
	{
		System.getProperty("Assignment4");
		Game g = new Game(); 
		g.run(); 
	}
	
}
