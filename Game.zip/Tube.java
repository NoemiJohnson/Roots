/*----------------------------------------------------------------*/
/* Author: 		Noemi Johnson
/* Class:  		CSCE 3193 
/* Title: 		Assignment 4
/* Date:        3/3/2018
/* Synopsis: 	Tube.java is part of the Game program
/*----------------------------------------------------------------*/

import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

//Tube class:
 public class Tube extends Sprite
 {
	static BufferedImage tube_image;
	
	//Boolean to determing to kill sprite:
	boolean kill_sprite = false; 
	
	boolean roastingGoomba = false;
	
	ArrayList<Sprite> sprites;
   
   Model model;
	
	//Tube constructor:
 	Tube(int x, int y, Model m)
	{
		model = m;
		this.x = x;
		this.y = y;
		w = 55;
		h = 95;
	
		sprites = new ArrayList<Sprite>();
		
		//Trying to lazy-load a tube image:
		if (tube_image == null)
		{
			tube_image = loadImage("tube.png");
		}	
	} 

 	
	public void draw(Graphics g)
	 {
		 //Drwaing the first tube:
		g.drawImage(Tube.tube_image, x - model.cameraPos(), y, null);
	 }
	
	
	void update()
	{
		//does nothing.This is for the Sprite abstract class.
	}
	
	//This will help the sprite class tell if it is a tube or not.
	boolean isTube()
	{
		return true;
	}
	
	//This will help the sprite class tell if it is a Mario or not.
	boolean isMario()
	{
		return false;
	}
	
	//This will help the sprite class tell if it is a Goomba or not.
	boolean isGoomba()
	{
		return false;
	}
	
	//Mario can collide with a tube. And Vice-Versa
	boolean isCollidable()
	{
		return true; 
	}
	
    boolean isFireball()
	{
		return false;
	}
	
	boolean isBBQGoomba()
	{
		return false;
	}

	//This is used for the lazy loading of the tube image:
	static BufferedImage loadImage(String filename)
	{
		BufferedImage tubey = null;
		//This code was added to the View constructor to load this image from disk: 
		try
		{
			//You need to use this to tell the compiler which tube object to use.
			tubey = ImageIO.read(new File(filename));	
		} 
		catch(Exception e) 
		{
			e.printStackTrace(System.err);
			System.exit(1);
		}
		return tubey;
	} 
	

	@Override
	public void rememberState() 
	{
		model.dest_x = this.x;
		model.dest_y = this.y;
	   	
				
	}
	

   
}