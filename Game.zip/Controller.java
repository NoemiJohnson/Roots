/*---------------------------------------------------------------------*/
/* Author: 		Noemi Johnson
/* Class:  		CSCE 3193 
/* Title: 		Assignment 4
/* Date:        3/3/2018
/* Synopsis: 	Controller.java is part of the side scroller map editor
/*---------------------------------------------------------------------*/

import java.awt.event.MouseListener;
import javax.imageio.ImageIO;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.FocusListener;
import java.awt.event.FocusEvent;


class Controller implements ActionListener, MouseListener, KeyListener
{
	//Member Variables:
	View view;
	Model model;
	Tube tube;
	Fireball fireball;
	
	
	boolean keyLeft;
	boolean keyRight;
	boolean keyUp;
	boolean keyDown;
	boolean keySpace;
	boolean keyCtrl;
	int queuedSpaces;
	int fireball_count;
	
	
	//Controller constructor takes in model object:
	Controller(Model m)
	{
		model = m;	
	
	}
	
	//Dr. Gashler recommended putting this method inside the Constructor, but it would give errors in my code:
	void setView(View v)
	{
		view = v;
	}
	
	//This method will implement the ActionListener class 
	public void actionPerformed(ActionEvent e)
	{
		this.model.update();	
	}
	
	//This method will implement the MouseListener class using the MouseEvent:
	public void mousePressed(MouseEvent e)
	{
		//This will access the x and y coordinates for the tube through the model object
		//This will help the program locate where the user clicks on the screen.
		this.model.setDestination(e.getX() + model.cameraPos(), e.getY());
			
	}
	
	public void mouseReleased(MouseEvent e) 
	{
			
	}
	
	public void mouseEntered(MouseEvent e) 
	{ 
			
	}
		
	public void mouseExited(MouseEvent e) 
	{ 
		
	}
	
	public void mouseClicked(MouseEvent e) 
	{
	
	}
	public void focusGained(FocusEvent e)
	{
		System.out.println("Focus gained!");
	}
	public void focusLost(FocusEvent e)
	{
		
	}
	
	//This method will activate if a key on the keyboard is pressed based on its direction.
	public void keyPressed(KeyEvent e)
	{
		switch(e.getKeyCode())
		{
			case KeyEvent.VK_RIGHT: keyRight = true; break;
			case KeyEvent.VK_LEFT: keyLeft = true; break;
			case KeyEvent.VK_UP: keyUp = true; break;
			case KeyEvent.VK_DOWN: keyDown = true; break;
			case KeyEvent.VK_SPACE: keySpace = true; queuedSpaces++; break;
			case KeyEvent.VK_CONTROL: keyCtrl = true; break;
			
		}
	}
	
    //This method will activate if the current directional key that was pressed is released
	public void keyReleased(KeyEvent e)
	{
		switch(e.getKeyCode())
		{
			case KeyEvent.VK_RIGHT: keyRight = false; break;
			case KeyEvent.VK_LEFT: keyLeft = false; break;
			case KeyEvent.VK_UP: keyUp = false; break;
			case KeyEvent.VK_DOWN: keyDown = false; break;
			case KeyEvent.VK_SPACE: keySpace = false; break;
			case KeyEvent.VK_CONTROL: keyCtrl = false; model.removeIt();  break;
		}
	}
     	 	
	 public void keyTyped(KeyEvent e)
	 {
		 
	  	  
	 }

	
	void update()
	{   
	    //Model backs up its old state of where Mario was:
	    model.rememberState();
		
		
		if(keyRight) 
		{
			model.mario.x += 10;
			
		}
		if(keyLeft)
		{
			model.mario.x -= 10;
			
		}
		//This command makes Mario jump if the up key  is pressed:
		//Adjusted the theOffGroundFrameCount to less than 2 to fix the jumping problem.
		if ((keyUp || queuedSpaces > 0) && model.mario.offGroundFrameCount < 2) 
		{
			model.mario.jump();
		}
		
		//This command makes Mario jump if the space bar is pressed:
		if ((keySpace || queuedSpaces > 0) && model.mario.offGroundFrameCount < 2)
		{
			model.mario.jump();
			
		}
		if (keyCtrl)
		{
			model.fireball.shoot();
		    model.addAnother();
			fireball_count = 10;
			
			if (fireball_count == 10)
			{	
				model.removeIt();
				model.addBBQGoomba();
		    }
		
		}
		else
		
		 
		fireball_count = 0;
		queuedSpaces = 0;
	}
		
}
