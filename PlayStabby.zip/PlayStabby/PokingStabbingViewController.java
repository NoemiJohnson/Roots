/*The PokingStabbingViewController Class is where it will feel for everything clicked and show it! */


import javafx.scene.input.*;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.stage.Stage;
import javafx.scene.layout.VBox;

public class PokingStabbingViewController extends VBox
{

	private MySkin skin;
	private Stage stage;
	private GraphicsContext gC;
	
	/*The Constructor */
	/*width the width of the Canvas rendering of mySkin */
	/*height the height of the Canvas rendering of mySkin*/

    public PokingStabbingViewController (MySkin skin, Stage stage, int width, int height)
    {
    	this.skin = skin;
 	    this.stage = stage;
    	Canvas canvas = new Canvas ( width, height);
 	    getChildren().add(canvas);
    	gC = canvas.getGraphicsContext2D();
 	
    	this.setOnMouseClicked( event -> handleMouseEvent (event));
    	this.setOnTouchPressed( event -> handleTouchEvent (event));
    }

	/*The handleMouseEvent method */
	
    public void handleMouseEvent (MouseEvent event)
    {
	    int x = (int) event.getSceneX();
	    int y = (int) event.getSceneY();
	    play (x, y);
    }

	/*The handleTouchEvent method */
	
    public void handleTouchEvent (TouchEvent event)
    {
    	int x = (int) event.getTouchPoint().getSceneX();
	    int y = (int) event.getTouchPoint().getSceneY();
	    play (x, y);
    }

	/* The play method */
	
	public void play (int x, int y)
	{
		skin.play(x, y);
		skin.draw(gC, x, y);
		stage.setTitle(skin.getStatus());
		if (skin.isStabbed())
		{
			this.setOnMouseClicked(null);
			this.setOnTouchPressed(null);
		}
	
	}

}