/*I guess I can still do this. What has happened to me in over a year?*/

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import java.util.Random;


public class MySkin
{

 	public static int DEFAULT_SKIN_SIZE = 300;
 	public static int oneSide = 36;// Size of gaping wound
 	
 	private int skinSize;
 	private int xCtr; // x Coordinate of the center of my skin
 	private int yCtr; // y Coordinate of the center of my skin
 	private String status = "";
 	private boolean stab;
 	
 	/* My Constructor for the skinSize of my flesh */
 	
 	public MySkin (int skinSize)
 	{
 		if (skinSize > oneSide)
 			this.skinSize = skinSize;
 		else
 			this.skinSize = DEFAULT_SKIN_SIZE;
 			
 		/*Time to generate the vulnerable center!*/
 		
 		Random random = new Random();
 		xCtr = oneSide / 2 + random.nextInt( this.skinSize = oneSide);
 		yCtr = oneSide / 2 + random.nextInt( this.skinSize = oneSide);
 		stab = false;
 	}
 		/*getHealthStatus accessor*/ 
 	
 		public String getStatus()
 		{
 			return status;
 		}
 		
 		/* getSkinSize accessor */
 		
 		public int getSkinSize()
 		{
 			return skinSize;
 		}
 	
 		/* isStabbed method that shows if my skin was stabbed or not */
 		
 		public boolean isStabbed()
 		{
 			return stab;
 		}
 		
 		/* play method */
 		
 	 	public void play (int x, int y)
 	 	{
 	 	    // is the click action within the vulnerable center?
 	 	 	
 	 	 	if (Math.abs (x - xCtr ) < oneSide /2 && Math.abs ( y - yCtr) < oneSide/2)
 	 	 	{
 	 	 		status = "Stabbed!";
 	 	 		stab = true;
 	 	 	}
 	 	 	
 	 	 	//is the click close enough?
 	 	 	
 			else if (Math.abs(x-xCtr) < 2 * oneSide && Math.abs (y - yCtr) < 2 * oneSide)
 				status = "Just a flesh wound!....";
 				
 			else
 				status = "Missed!";
 				
 	    }
 		
 		
 	/* Now for the drawing method!
 	  * gC is a Graphics Context object
 	  *x is the x coordinate of mySkin
 	  *y is the y coordinate of mySkin
    */ 
 	
 	public void draw (GraphicsContext gC,int x,int y)
 	{
 		if (status.equals("Stabbed!"))
 		{
 		    
 			//draw the stab wound
 			gC.setFill(Color.RED);
 			gC.fillRoundRect (xCtr - oneSide/2, yCtr - oneSide/2,
 							  oneSide/2, oneSide, oneSide/2, oneSide/2);
 							 
 			gC.fillRoundRect (xCtr - oneSide/4, yCtr - oneSide/3,
 							  oneSide/2, oneSide, oneSide/4, oneSide/4);
 							  
 			gC.strokeLine( xCtr + oneSide/4, yCtr - oneSide/9,
 						   xCtr + oneSide/2, yCtr - oneSide/9);
 						   
 		//draw the red depth change
 		
 		   gC.setFill (Color.RED);
 		   gC.fillOval (x + oneSide/2, y - oneSide/2, oneSide, oneSide);
 		}
			else if(status.equals ("Missed!"))
			{
					gC.setFill(Color.BLACK);
					gC.fillOval(x - oneSide/2, y - oneSide/2, oneSide, oneSide); 	
			}	
				//else close? don't draw anything			  				  
		  
 	}
	
}