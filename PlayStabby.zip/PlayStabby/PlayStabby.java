/* The PlayStabby Class */

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class PlayStabby extends Application
{
	private final int SKIN_SIZE = 500;
	
	@Override
	public void start (Stage stage)
	{
		MySkin skin = new MySkin (SKIN_SIZE);
		PokingStabbingViewController root = 
			new PokingStabbingViewController( skin, stage, SKIN_SIZE, SKIN_SIZE);
	
		Scene scene = new Scene (root, 500, 500);
		stage.setTitle ("Attack!!");
		stage.setScene (scene);
		stage.show();

	}

	public static void main (String [] args )
	{
		launch(args);
	}

}